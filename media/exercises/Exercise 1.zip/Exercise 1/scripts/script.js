console.log("Test");


const bkg1 = document.querySelector("#bkg1");
const bkg2 = document.querySelector('#bkg2');
const button = document.querySelector('#btn');
const text0 = "<p>Click to blend colors</p>";
const text1 = "<p>Click to seperate colors</p>";

let buttonToggled = false;

button.addEventListener('click', colorSwitcher);

function colorSwitcher() {

    if (buttonToggled) {

        bkg1.style.background = "#1900ff"
        bkg2.style.background = "#ff0000"
        button.innerHTML = text0;

        buttonToggled = false;
    } else {
    
        bkg1.style.background = "#aa00ff"
        bkg2.style.background = "#aa00ff"
        button.innerHTML = text1;

        buttonToggled = true;
    }
    
};