const startBTN = document.querySelector('#buttonContainer');
const cupIMGs = document.querySelectorAll('.cupOverlay');
const cupSpaces = document.querySelectorAll('.cupSpace');

let isGameStarted = false;
let timesWon = 0;
let timesLost = 0;

startBTN.addEventListener('click', gameStart);

for (let i = 0; i < cupSpaces.length; i++) {
    cupSpaces[i].addEventListener('click', winCheck);
}


function gameStart () {

    cupSpinAnim();
    isGameStarted = true;
}

function cupSpinAnim () {

    for (let i = 0; i < cupIMGs.length; i++) {
        cupIMGs[i].style.animation = 'cupSpin 1s linear infinite';
    }
}

function cupStatic() {

    for (let i = 0; i < cupIMGs.length; i++) {
        cupIMGs[i].style.animation = '';
    }
}

function winCheck () {
    let min = Math.ceil(1);
    let max = Math.floor(3);
    let result = Math.floor(Math.random() * (max - min +1)) + min;

    cupStatic();

    if (isGameStarted) {
        
        if (result == 1) {
            timesWon++;
            alert("You found the ball! You Win!\nWins = " + timesWon + " / Losses = " + timesLost);
            
        } else {
            timesLost++;
            alert("You Lose. Loser.\nWins = " + timesWon + " / Losses = " + timesLost);
            
        }

        isGameStarted = false;
    }
    
  
}

