//GLOBAL CONSTS//
const button = document.querySelector("#convertBTN");

//GLOBAL VARIABLES//
let bkgColor = document.querySelector("#bkg");
let rValue = document.getElementById("sliderR");
let gValue = document.getElementById("sliderG");
let bValue = document.getElementById("sliderB");
let hexOut = document.querySelector("#hexOutput");
let rOut = document.querySelector("#rOutput");
let gOut = document.querySelector("#gOutput");
let bOut = document.querySelector("#bOutput");

//RGB SLIDER LISTENERS//
rValue.addEventListener('input', returnValueR);
gValue.addEventListener('input', returnValueG);
bValue.addEventListener('input', returnValueB);

//BUTTON EVENT HANDLER//
button.onclick = function() {generateNewColor()};

//CUSTOM FUNCTIONS//
function returnValueR() {
    rOut.textContent = this.value;
}
function returnValueG() {
    gOut.textContent = this.value;
}
function returnValueB() {
    bOut.textContent = this.value;
}
function generateNewColor() {
    let newHex;
    r = document.getElementById("sliderR").value;
    g = document.getElementById("sliderG").value;
    b = document.getElementById("sliderB").value;

    newHex = hexConvert(r,g,b);

    hexOut.textContent = newHex;

    bkgColor.style.background = newHex;

}
function hexConvert(r, g, b) {
    return "#" + (1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1);
}